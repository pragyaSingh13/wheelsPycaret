extending.pyx
-------------

.. literalinclude:: ../../../../../../numpy/random/_examples/cython/extending.pyx
    :language: cython
