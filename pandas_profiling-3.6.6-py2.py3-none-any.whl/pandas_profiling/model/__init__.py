"""The model module handles all logic/calculations, e.g. calculate statistics, testing for special conditions."""
